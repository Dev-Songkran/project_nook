<?php 
session_start();
$sess_usrid=$_SESSION[sess_usrid];
$sess_usrname=$_SESSION[sess_usrname];
$ssid=$_SESSION[ssid];
if (session_id()=="" or $sess_usrname=="" or $ssid=="") {

 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>เข้าสู่ระบบจัดการข้อมูลยา</title>
    <link rel="stylesheet" href="assets/css/login.css">
    <link rel="stylesheet" href="https://dev-songkran.github.io/CDN/plugins/alertifyjs/css/alertify.css?v=1">
    <link rel="stylesheet" href="https://dev-songkran.github.io/CDN/plugins/alertifyjs/css/themes/default.css?v=1">
</head>

<body>
    <div class="container">
        <div class="info">
            <!--<h1>ระบบบริหารจัดการเอกสารงานธุรการออนไลน์</h1>-->
            <h1>ระบบจัดการเว็บไซต์</h1>
        </div>
    </div>
    <div class="form">
        <div class="thumbnail"><img src="images/logo.png" /></div>
        <form class="login-form" method="post">
            <input name="usr" type="text" placeholder="username"  required />
            <input name="pwd" type="password" placeholder="password" required  />
            <input type="submit" name="login" value="LOGIN">
        </form>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://dev-songkran.github.io/CDN/plugins/alertifyjs/alertify.js?v=1"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
<?php }else{ ?>
<script>location.replace('./')</script>
<?php } ?>