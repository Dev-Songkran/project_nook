<?php 
session_start();
session_destroy();
$link = "http://$_SERVER[HTTP_HOST]/";
echo "<script>location.replace('".$link."project/login.php')</script>";
 ?>