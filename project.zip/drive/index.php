<?php 
include '../inc/session.php';
include '../inc/config.inc.php';
include '../inc/function.php';
$type = intval($_GET[type]);
$sel = select("$tb_menu","where id='$type'");
 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ระบบบริหารจัดการเอกสารงานธุรการออนไลน์</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.24.3/css/uikit.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.uikit.min.css">
    <link rel="stylesheet" href="../plugins/alertifyjs/css/alertify.css">
    <link rel="stylesheet" href="../plugins/alertifyjs/css/themes/default.css">
</head>

<body>
    <?php include '../head.php'; //นำเข้าไฟล์หัวเว็บ ?>
    <?php include '../menu.php'; //นำเข้าไฟล์เมนู ?>
    <section class="main">
        <div class="page-content">
            <div class="page-title">
                <?php echo $sel[topic] ?>
            </div>
            <div class="">
                <form action="control/command.php" method="post" enctype="multipart/form-data" target="ifr">
                    <input type="hidden" value="<?php echo $id ?>" name="per_id">
                    <div style="width: 100px;    border-radius: 0;    height: 40px;" class="btn btn-success upload">
                        อัพโหลดไฟล์
                        <input type="file" data-upload="true" data-type="jpg,jpeg,pdf,doc,docx,xls,xlsx,zip" data-alert="เฉพาะไฟล์ jpg,jpeg,pdf,doc,docx,xls,xlsx,zip เท่านั้น" name="filename1">
                    </div>
                    <input id="upload" type="submit" name="upload" style="display: none;">
                </form>
                <br>
                <div class="cards">
                    <div class="body">
                        <table id="example" class="uk-table uk-table-hover uk-table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <td width="50" align="center"></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $data = select_all("$tb_drive","order by id desc");
                                    if($data<>""){
                                    foreach ($data as $rs) {
                                        $ext = strtolower(end(explode('.', $rs[filename])));
                                        if($ext === 'jpg' || $ext === 'png'){
                                            $file = '<div class="item-list" style="background:url(../filesAttach/drive/'.$rs[filename].')"></div>';
                                        }else{
                                            $file = '<div class="item-list"><i class="material-icons">file_download</i></div>';
                                        }
                                 ?>
                                <tr class="item-file">
                                    <td>
                                       <?php echo $file ?>
                                       <div class="text">
                                           <p><?php echo $rs[name] ?></p>
                                           <a download="../filesAttach/drive/<?php echo $rs[filename] ?>" href="<?php echo $rs[name] ?>"><i class="material-icons">file_download</i></a>
                                           <a class="del" data-del="true" data-id="<?php echo $rs[id] ?>" data-file="<?php echo $rs[filename] ?>" href="javascript:void()"><i class="material-icons">close</i></a>
                                       </div>
                                    </td>
                                </tr>
                                <?php } } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <iframe src="" name="ifr" style="display: none;" frameborder="0"></iframe>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="../plugins/alertifyjs/alertify.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.uikit.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>

</html>
