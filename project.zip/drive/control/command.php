<?php 
include '../../inc/config.inc.php';
include '../../inc/function.php';

if(isset($_POST[upload])){
    if($_FILES['filename1']['tmp_name']<>""){
        $part1="../../filesAttach/drive/";
        $part2="../../filesAttach/drive/thumbnail/";
        $size1=900;
        $size2=300;
        $file_temp=$_FILES['filename1']['tmp_name'];
        $file_name=$_FILES['filename1']['name'];
        $file_type=$_FILES['filename1']['type'];
        $newFiles=imagesFile($file_temp,$file_name,$file_type,$part1,$part2,$size1,$size2);
    }
    insert("$tb_drive","filename,name","'$newFiles','$file_name'");
    echo "<script>window.top.success('$file_name','')</script>";
}

if(isset($_POST[del])){
    @unlink("../../filesAttach/drive/$_POST[file]");
    @unlink("../../filesAttach/drive/thumbnail/$_POST[file]");
    delete("$tb_drive","where id='$_POST[id]'");
    echo "true";
}

 ?>