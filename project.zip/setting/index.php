<?php 
include '../inc/session.php';
include '../inc/config.inc.php';
include '../inc/function.php';

 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ระบบบริหารจัดการเอกสารงานธุรการออนไลน์</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.24.3/css/uikit.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.uikit.min.css">
    <link rel="stylesheet" href="../plugins/alertifyjs/css/alertify.css">
    <link rel="stylesheet" href="../plugins/alertifyjs/css/themes/default.css">
</head>

<body>
    <?php include '../head.php'; //นำเข้าไฟล์หัวเว็บ ?>
    <?php include '../menu.php'; //นำเข้าไฟล์เมนู ?>
    <section class="main">
        <div class="page-content">
            <div class="page-title">
                ระบบจัดการประเภทข่าว
            </div>
            <div class="">
                <a data-modal="true" class="bttn-unite bttn-sm bttn-primary" href="javscript:void(0)">เพิ่มข้อมูล</a>
                <br>
                <br>
                <div class="cards">
                	<div class="body">
                		<table id="example" class="uk-table uk-table-hover uk-table-striped" cellspacing="0" width="100%">
					        <thead>
					            <tr>
                                    <td width="50" align="center">ลำดับ</td>    
                                    <td align="center">หัวข้อ</td>           
                                    <td width="150" align="center">จัดการ</td>
                                </tr>
					        </thead>
					        
					        <tbody>
                                <?php 
                                    $sql = "SELECT * FROM $news_type order by id ASC";
                                    $qry = mysql_query($sql);
                                    $count = 1;
                                    while ($rs=mysql_fetch_array($qry)) {
                                 ?>
                                <tr>
                                    <td style="vertical-align: middle;" align="center"><?php echo $count ?></td>
                                    <td style="vertical-align: middle;"><?php echo $rs[topic] ?></td>
                                    <td style="vertical-align: middle;" align="center">
                                        <a href="javascript:void(0)" data-modal="true" data-id="<?php echo $rs[id] ?>" data-topic="<?php echo $rs[topic] ?>" class="btn btn-warning">
                                            <i class="material-icons">edit</i>
                                        </a>
                                        <a class="btn btn-danger" data-id="<?php echo $rs[id] ?>" data-del="all" data-file="<?php echo $rs[filename] ?>" href="javascript:void(0)">
                                            <i class="material-icons">close</i>
                                        </a>
                                    </td>
                                </tr>
                                <?php $count++; } ?>
					        </tbody>
					    </table>
                	</div>
                </div>
            </div>
        </div>
    </section>
    <section></section>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="../plugins/alertifyjs/alertify.js"></script>    
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.uikit.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>

</html>
