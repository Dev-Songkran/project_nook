<?php 
include '../../inc/config.inc.php';
include '../../inc/function.php';

if(isset($_POST[save])){
	if($_POST[id]<>""){
		update("$news_type","topic='$_POST[topic]'");
		echo "true";
	}else{
		insert("$news_type","topic","'$_POST[topic]'");
		echo "true";
	}
}
if(isset($_POST[del])){
	delete("$news_type","where id='$_POST[id]'");
	echo "true";
}

 ?>