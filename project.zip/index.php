<?php include 'inc/session.php'; ?>
<script>
	location.replace('report/?type=1')
</script>