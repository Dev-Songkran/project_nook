$(document).ready(function() {
    var w = $('[data-width]');
    if (w.length > 0) {
        $(w).css('width', $('[data-width]').data('width'));
    }
    if ($('#example').length > 0) {
        $('#example').DataTable({
            "bSort": false,
            "bLengthChange": false,
            "bInfo": false,
            "language": {
                "search": "ค้นหา : ",
                "zeroRecords": ":: ไม่พบข้อมูล ::",
            },
        });
    }
})
$(document).on('change', 'input[type="file"]', function() {
    var file = $(this)["0"].files["0"];
    var extall = $(this).data('type');
    var ext = $(this)["0"].value.split('.').pop().toLowerCase();
    var a = '<font style="color:red;font-family:Prompt">' + $(this).data('alert') + '</font>';
    var upload = $(this).data('upload');
    if (file) {
        if (parseInt(extall.indexOf(ext)) < 0) {
            alertify.alert('แจ้งเตือน', a, function() {});
            $(this).val('');
        } else {
            if (upload === true) {
                $('#upload').click();
            }
        }
    } else {
        $(this).val('');
    }
});

function success(text, url) {
    alertify.alert('แจ้งเตือน', text, function() {
        setTimeout(function() {
            location.replace(url);
        }, 200)
    });
}
function textEditor() {
    tinymce.init({
        selector: 'textarea',
        language: 'th_TH',
        menubar: false,
        plugins: [
            'advlist autolink lists link image charmap print preview hr anchor pagebreak',
            'searchreplace wordcount visualblocks visualchars code fullscreen',
            'insertdatetime media nonbreaking save table contextmenu directionality',
            'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help'
        ],
        theme_advanced_buttons3_add: "preview",
        plugin_preview_width: "1000",
        plugin_preview_height: "600",
        toolbar1: 'bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect | fontsizeselect ',
        toolbar2: ' copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink image code | preview | forecolor backcolor ',
        toolbar3: ' table | hr removeformat | emoticons media | fullscreen ',
        height: 350,

    });
}

$(document).on('click', '[data-del]', function() {
    var id = $(this).data('id');
    var file = $(this).data('file');
    var type = $(this).data('del');
    var no = $(this).data('no');
    alertify.confirm('แจ้งเตือน', "คุณต้องการลบข้อมูลนี้ใช่หรือไม่ !?",
        function() {
            alertify.success('ลบข้อมูลเรียบร้อยแล้ว');
            $.ajax({
                url: 'control/command.php',
                type: 'post',
                data: {
                    id: id,
                    file: file,
                    no: no,
                    del: type,
                },
                success: function(data) {
                    if (data) {
                        setTimeout(function() { location.replace(''); }, 150)

                    }
                    if (data == "OK") {
                        return true;
                    } else {
                        return false;
                    }
                }
            })
        },
        function() {
            alertify.error('ยกเลิก');
        });
});
$(document).on('click','[data-dialog]',function(){
    var id = $(this).data('id');
    $.getJSON('control/command.php?api='+id,function(data){
        alertify.alert('รายละเอียด',data.detail).maximize(); 
    })
});

$(document).on('click','[data-change-file]',function(){
    var file = $(this).data('file');
    $('.change_file').html('<input data-type="pdf,xlsx,xls,doc,docx,zip,rar" data-alert="เฉพาะไฟล์ jpg,jpeg,pdf,doc,docx,xls,xlsx,zip เท่านั้น" type="file" name="filename1" /> <a data-file-old="true" data-file="'+file+'" class="btn btn-success tootip" data-tootip="ใช้ไฟล์เดิม" href="javascript:void(0)"><i class="material-icons">cached</i></a>').fadeIn();
});
$(document).on('click','[data-file-old]',function(){
    var file = $(this).data('file');
    $('.change_file').html('<a class="link" href="'+file+'" target="_blank">ดูไฟล์แนบ</a> <a class="btn btn-warning tootip" data-change-file="true" data-tootip="เปลี่ยนไฟล์" data-file="'+file+'" href="javascript:void(0)"><i class="material-icons">file_upload</i></a>')
});
$(document).on('click', '[data-modal]', function() {
    var id = $(this).data('id');
    var topic = $(this).data('topic');
    var p = alertify.prompt();
    if(topic !== undefined){
        var t = 'แก้ไขประเภทข่าว';
    }else{
        var t = 'เพิ่มประเภทข่าว';
    }
    p.set({
        labels: { ok: 'บันทึกข้อมูล', cancel: 'ยกเลิก' },
        autoReset: true,
        transition: 'zoom',
        onshow: function() {
            console.log(topic)
            $('.ajs-input').val(topic);
        },
        onok: function(ev, value) {
            alertify.success('บันทึกข้อมูลเรียบร้อยแล้ว');
            $.ajax({
                url: 'control/command.php',
                type: 'post',
                data: {
                    save: 'true',
                    topic: value,
                    id: id,
                },
                success: function(data) {
                    if (data) {
                        location.replace('');
                    }
                    if (data === "OK") {
                        return true;
                    } else {
                        return false;
                    }
                }
            })
        }
    }).setHeader(t).show();;

})
$(document).on('submit','form.login-form',function(){
    var formData  =  new FormData(this);
    $.ajax({
        url : 'inc/check.php',
        type : 'post',
        data : formData,
        cache: false,
        contentType: false,
        processData: false,
        success:function(data,status){
            if(data==='true'){
                location.replace("./");
            }else{
                alertify.alert('แจ้งเตือน','ชื่อผู้ใช้งาน หรือ รหัสผ่านผิดพลาด !!');
            }
        }
    });
    return false;
});