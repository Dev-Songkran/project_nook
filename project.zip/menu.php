<div class="menu">
    <a href="<?php echo $backend ?>report/?type=1">
        <i class="material-icons">show_chart</i>
        <span>ข้อมูลสถิติข่าว</span>
    </a>
    <a href="<?php echo $backend ?>report/?type=2">
        <i class="material-icons">directions_car</i>
        <span>ข้อมูลรายงานการใช้รถ</span>
    </a>
    <a href="<?php echo $backend ?>report/?type=3">
        <i class="material-icons">warning</i>
        <span>ข้อมูลรายงานปัญหาการขัดข้อง</span>
    </a>
    <a href="<?php echo $backend ?>report/?type=4">
        <i class="material-icons">healing</i>
        <span>ข้อมูลสรุปวันลา</span>
    </a>
    <a href="<?php echo $backend ?>report/?type=5">
        <i class="material-icons">report</i>
        <span>ข้อมูลรายงานประจำเดือน</span>
    </a>
    <a href="<?php echo $backend ?>drive/">
        <i class="material-icons">file_upload</i>
        <span>ระบบอัพโหลดไฟล์</span>
    </a>
    <a href="<?php echo $backend ?>setting/">
        <i class="material-icons">settings</i>
        <span>ระบบจัดการประเภทข่าว</span>
    </a>
    <a href="<?php echo $backend ?>logout.php">
        <i class="material-icons">power_settings_new</i>
        <span>ออกจากระบบ</span>
    </a>
</div>
