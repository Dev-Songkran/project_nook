<?
session_start();
$sess_usrid=$_SESSION[sess_usrid];
$sess_usrname=$_SESSION[sess_usrname];
$ssid=$_SESSION[ssid];
$link = "http://$_SERVER[HTTP_HOST]/";
if ($sess_usrid<>session_id() or $sess_usrname=="" or $ssid=="") {
    echo "<script>location.replace('".$link."project/login.php')</script>";
} 
?>