<?php 
//=============== Insert ================== 
function insert($table,$field,$value)
{
$sql = "INSERT INTO $table ($field) VALUES ($value)";
$result= mysql_query($sql);
return $result;
}

//============== delete ==============
function delete($table,$condition)
{
$sql ="delete from $table $condition";
$result = mysql_query($sql);
return $result;
}

//=============== Numrow ================== 
function num_record($table,$condition)
{
$sql = "select * from $table $condition";
$dbquery = mysql_query($sql);
$num_rows = mysql_num_rows($dbquery);
return $num_rows;
}


//=============== update ==================
function update($table,$command,$condition)
{
$sql = "UPDATE $table SET $command $condition";
$result = mysql_query($sql);
return $result;
}

//=============== select ================== 
function select($table,$condition)
{
$sql = "select * from $table $condition";
$dbquery = mysql_query($sql);
$result= mysql_fetch_array($dbquery);
return $result;
}

function select_all($table,$condition)
{
$sql = "select * from $table $condition";
$dbquery = mysql_query($sql);
$result = NULL;
$i = 0;
while($row = mysql_fetch_array($dbquery))
{
	$result[$i] = $row;
	$i++;
}
return $result;
}


function imagesFile($file_temp,$file_name,$file_type,$part1,$part2,$size1,$size2){
		if($file_name<>""){
					$rename =time(); 
					$ext = strtolower(end(explode('.',$file_name)));
					if ($ext=="jpg" or $ext=="jpeg" or $ext=="gif") {

								$newFile=$rename.".$ext";
								copy($file_temp,"$part1$newFile");		

							if ($ext=="jpg" or $ext=="jpeg") {
									$ori_img = imagecreatefromjpeg($file_temp);
							}else{	
									$ori_img = imagecreatefromgif($file_temp);
							}
										$ori_size = getimagesize($file_temp);
										$ori_w = $ori_size[0]; 
										$ori_h = $ori_size[1];

											if ($ori_w >$size1) {
													$new_w = $size1; 
													$new_h = round(($new_w/$ori_w) * $ori_h);
													$new_img= imagecreatetruecolor($new_w, $new_h);
													imagecopyresized($new_img, $ori_img,0,0,0,0,$new_w, $new_h,$ori_w,$ori_h);
													imageString($new_img, 5, 20, 5, "",'');
													imagejpeg($new_img,"$part1$newFile");
													imagedestroy($ori_img); 
													imagedestroy($new_img); 
												}

							$thumbDir = "$part2" ;
							$thumbfile = $thumbDir . $newFile; 
							list($w1, $h1) = getimagesize($part1.$newFile);
							$quality = 100;
							$w2 =$size2 ; 
							$percent = $w2 / $w1 ;
							$h2 = $h1 * $percent ;
							$im = imageCreateTrueColor($w2, $h2);	
								if($ext=="jpg" or $ext=="jpeg"){
									$im1 = imageCreateFromJpeg($part1.$newFile); 
								}else if($ext=="gif"){
									$im1 = imageCreateFromgif($part1.$newFile); 
								}
							imageCopyResampled($im, $im1, 0, 0, 0, 0, $w2, $h2, $w1, $h1);
							imagejpeg($im, $thumbfile , $quality);	# %
							imageDestroy($im);
							imageDestroy($im1);
					}
							if ($ext=="doc" or $ext=="docx" or $ext=="pdf" or $ext=="zip" or $ext=="rar" or $ext=='xls' or $ext=='xlsx') {
								$newFile=$rename.".$ext";
								copy($file_temp,"$part1$newFile");	
						}
			@unlink("$file_temp");		
		}
		return $newFile;		
		
}
function datathai($date){	
	$day = explode('-', $date);
	$d = $day[2];
	$m = $day[1];
	$y = $day[0];

	$array = array('','มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กพกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม');
	$month = $array[(int)$m];
	$year  = $y+543;
	$date_thai = "$d $month $year";
	return $date_thai;
	
}
 ?>