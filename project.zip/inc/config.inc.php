<?php 
/*
$host = 'localhost';
$usr = 'drugiden_user';
$pwd = 'b4TinCtwFx';
$db  = 'drugiden_project';
*/

$host = 'localhost';
$usr = 'root';
$pwd = '123456';
$db  = 'project';

$tb_admin = 'tb_admin';
$tb_menu = 'tb_menu';
$news_type = 'tb_news_type';
$tb_report = 'tb_report';
$tb_drive = 'tb_drive';

mysql_connect($host,$usr,$pwd) or die ("ไม่สามารถเชื่อมต่อกับฐานข้อมูลได้");
mysql_query("set NAMES utf8");
mysql_select_db($db) or die ("ไม่สามารถเลือกฐานข้อมูลได้");
//$backend = 'https://drug-iden.com/project/';
$backend = '//localhost/project/';
 ?>