<?php
ob_start();
session_start();
include 'config.inc.php';
include 'function.php';
if(isset($_POST[usr])){
    $usr = md5($_POST[usr]);
    $pwd = md5($_POST[pwd]);
    $sql = "SELECT * FROM $tb_admin where usr='$usr' and pwd='$pwd' and id='1'";
    $qry = mysql_query($sql);
    $res = mysql_fetch_assoc($qry);
    if(mysql_num_rows($qry)>0){
        $_SESSION['sess_usrid'] = session_id();
        $_SESSION['sess_usrname'] = $usr;
        $_SESSION['ssid'] = $res[id];
        echo 'true';
    }else{
        echo 'false';
    }
}
 ?>
