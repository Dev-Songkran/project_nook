<?php 
include '../inc/session.php';
include '../inc/config.inc.php';
include '../inc/function.php';
$type = intval($_GET[type]);
$sel = select("$tb_menu","where id='$type'");
 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ระบบบริหารจัดการเอกสารงานธุรการออนไลน์</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.24.3/css/uikit.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.uikit.min.css">
    <link rel="stylesheet" href="../plugins/alertifyjs/css/alertify.css">
    <link rel="stylesheet" href="../plugins/alertifyjs/css/themes/default.css">
</head>

<body>
    <?php include '../head.php'; //นำเข้าไฟล์หัวเว็บ ?>
    <?php include '../menu.php'; //นำเข้าไฟล์เมนู ?>
    <section class="main">
        <div class="page-content">
            <div class="page-title">
                <?php echo $sel[topic] ?>
            </div>
            <div class="">
                <a class="bttn-unite bttn-sm bttn-primary" href="form.php?type=<?php echo $type ?>">เพิ่มข้อมูล</a>
                <br>
                <br>
                <div class="cards">
                	<div class="body">
                		<table id="example" class="uk-table uk-table-hover uk-table-striped" cellspacing="0" width="100%">
					        <thead>
					            <tr>
                                    <td width="50" align="center">ลำดับ</td>    
                                    <td align="center">หัวข้อ</td>           
                                    <?php if($type==1){ ?>
                                    <td width="99" align="center">ประเภทข่าว</td>
                                    <?php } ?>
                                    <td width="70" align="center">ไฟล์แนบ</td>
                                    <td width="70" align="center">รายละเอียด</td>
                                    <td width="150" align="center">จัดการ</td>
                                </tr>
					        </thead>
					        
					        <tbody>
                                <?php 
                                    $sql = "SELECT * FROM $tb_report where type='$type' order by id DESC";
                                    $qry = mysql_query($sql);
                                    $count = 1;
                                    while ($rs=mysql_fetch_array($qry)) {
                                 ?>
                                <tr>
                                    <td style="vertical-align: middle;" align="center"><?php echo $count ?></td>
                                    <td style="vertical-align: middle;"><?php echo $rs[topic] ?></td>
                                    <?php 
                                        if($type==1){
                                        $tnews = select("$news_type","where id='$rs[news_type]'");
                                        if($tnews[topic]!=""){
                                            $topic_news = $tnews[topic];
                                        }else{
                                            $topic_news = '-';
                                        }
                                    ?>
                                    <td style="vertical-align: middle;" align="center"><?php echo $topic_news ?></td>
                                    <?php } ?>
                                    <td style="vertical-align: middle;" align="center">
                                    <?php if($rs[filename]!=""){ ?>
                                        <a href="../filesAttach/report/<?php echo $rs[filename] ?>" target="_blank">
                                            <i class="material-icons">file_download</i>
                                        </a>
                                    <?php }else{ echo '-'; } ?>
                                    </td>
                                    <td style="vertical-align: middle;" align="center">
                                        <a data-id="<?php echo $rs[id] ?>" href="javascript:void(0)" data-dialog="true">
                                            <i class="material-icons">visibility</i>
                                        </a>
                                    </td>
                                    <td style="vertical-align: middle;" align="center">
                                        <a target="_blank" class="btn btn-info" href="report.php?id=<?php echo $rs[id] ?>">
                                            <i class="material-icons">assignment</i>
                                        </a>
                                        <a href="form.php?id=<?php echo $rs[id] ?>&type=<?php echo $type ?>" class="btn btn-warning">
                                            <i class="material-icons">edit</i>
                                        </a>
                                        <a class="btn btn-danger" data-id="<?php echo $rs[id] ?>" data-del="all" data-file="<?php echo $rs[filename] ?>" href="javascript:void(0)">
                                            <i class="material-icons">close</i>
                                        </a>
                                    </td>
                                </tr>
                                <?php $count++; } ?>
					        </tbody>
					    </table>
                	</div>
                </div>
            </div>
        </div>
    </section>
    <section></section>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="../plugins/alertifyjs/alertify.js"></script>    
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.uikit.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>

</html>
