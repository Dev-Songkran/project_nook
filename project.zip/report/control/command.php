<?php 
include '../../inc/config.inc.php';
include '../../inc/function.php';

if(isset($_POST[save])){
    if($_FILES['filename1']['tmp_name']<>""){
        $part1="../../filesAttach/report/";
        $part2="../../filesAttach/report/thumbnail/";
        $size1=900;
        $size2=300;
        $file_temp=$_FILES['filename1']['tmp_name'];
        $file_name=$_FILES['filename1']['name'];
        $file_type=$_FILES['filename1']['type'];
        $newFiles=imagesFile($file_temp,$file_name,$file_type,$part1,$part2,$size1,$size2);

        //check file insert
        if(file_exists("../../filesAttach/report/".$newFiles)){
            @unlink("../../filesAttach/report/$_POST[file_old]");
            @unlink("../../filesAttach/report/thumbnail/$_POST[file_old]");
        }else{
            $newFiles = $_POST[file_old];
        }
    }else{
        $newFiles = $_POST[file_old];
    }
    if($_POST[id]!=""){
        update("$tb_report","news_type='$_POST[news_type]',topic='$_POST[topic]',detail='$_POST[detail]',filename='$newFiles',postdate='$_POST[postdate]'","where id='$_POST[id]'");
    }else{
        insert("$tb_report","type,news_type,topic,detail,filename,postdate","'$_POST[type]','$_POST[news_type]','$_POST[topic]','$_POST[detail]','$newFiles','$_POST[postdate]'");
    }
    echo "<script>window.top.success('บันทึกข้อมูลเรียบร้อย','./?type=".$_POST[type]."')</script>";
}

if(isset($_POST[del])){
    if($_POST[file]!=""){
        @unlink("../../filesAttach/report/$_POST[file]");
        @unlink("../../filesAttach/report/thumbnail/$_POST[file]");
    }
    delete("$tb_report","where id='$_POST[id]'");
    echo "true";
}

if(isset($_GET[api])){
    $sel = select("$tb_report","where id='$_GET[api]'");
    $json = array("detail" => $sel[detail]);
    echo json_encode($json);
}


?>