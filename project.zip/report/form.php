<?php 
include '../inc/session.php';
include '../inc/config.inc.php';
include '../inc/function.php';
$type = intval($_GET[type]);
$sel = select("$tb_menu","where id='$type'");
if($_GET[id]!=""){
    $id = intval($_GET[id]);
    $data = select("$tb_report","where id='$id'");
    $t = 'แก้ไข';
}else{
    $t = 'เพิ่ม';
}

 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ระบบบริหารจัดการเอกสารงานธุรการออนไลน์</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../plugins/alertifyjs/css/alertify.css">
    <link rel="stylesheet" href="../plugins/alertifyjs/css/themes/default.css">

</head>

<body>
    <?php include '../head.php'; //นำเข้าไฟล์หัวเว็บ ?>
    <?php include '../menu.php'; //นำเข้าไฟล์เมนู ?>
    <section class="main">
        <div class="page-content">
            <div class="page-title">
                <?php echo $t.$sel[topic] ?>
            </div>
            <div class="">
                <div class="cards">
                	<div class="body">
                		<form action="control/command.php" method="post" enctype="multipart/form-data" target="ifr" >
                            <input type="hidden" name="type" value="<?php echo $type ?>">
                            <input type="hidden" name="id" value="<?php echo $id ?>">
                            <input type="hidden" name="file_old" value="<?php echo $data[filename] ?>">
                            <div class="form-group">
                                <label for="topic">หัวข้อ</label>
                                <input data-width="57%" id="topic" class="form-control" name="topic" type="text" value="<?php echo $data[topic] ?>">
                            </div>
                            <div class="form-group">
                                <label for="postdate">วันที่</label>
                                <input id="postdate" class="form-control" name="postdate" type="date" value="<?php echo $data[postdate] ?>">
                            </div>
                            <?php if($type==1){ ?>
                            <div class="form-group">
                                <label for="news_type">ประเภทข่าว</label>
                                <select class="form-control" name="news_type" id="news_type">
                                    <option value="">--- กรุณาเลือกประเภทข่าว ---</option>
                                <?php 
                                    $n_data = select_all("$news_type"," order by id ASC");
                                    if($n_data<>""){
                                        foreach ($n_data as $rs) {
                                            if($data[news_type]==$rs[id]){
                                                $sl = 'selected';
                                            }else{
                                                $sl = '';
                                            }
                                ?>
                                <option value="<?php echo $rs[id] ?>" <?php echo $sl ?>><?php echo $rs[topic] ?></option>
                                <?php }} ?>
                                </select>
                            </div>
                            <?php } ?> 
                            <div class="form-group">
                                <label for="filename1">ไฟล์แนบ</label>
                                <?php if($data[filename]==""){ ?>
                                <input data-type="pdf,xlsx,xls,doc,docx,zip,rar" data-alert="เฉพาะไฟล์ .pdf , .xlsx , .xls , .doc , .docx , .zip , .rar" id="filename1"  name="filename1" type="file">
                                <?php }else{ ?>
                                <div class="change_file">
                                    <a class="link" href="../filesAttach/report/<?php echo $data[filename] ?>" target="_blank">ดูไฟล์แนบ</a> 
                                    <a class="btn btn-warning tootip" data-change-file="true" data-tootip="เปลี่ยนไฟล์" data-file="../filesAttach/report/<?php echo $data[filename] ?>" href="javascript:void(0)"><i class="material-icons">file_upload</i></a>
                                </div>
                                <?php } ?>
                            </div>     
                            <div class="form-group">
                                <label class="v-top" for="detail">รายละเอียด</label>
                                <textarea name="detail" id="detail" class="form-control" data-width="100%" cols="30" rows="10"><?php echo $data[detail] ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="" class="no-before"></label>
                                <button class="bttn-unite bttn-sm bttn-success" name="save">บันทึกข้อมูล</button>
                                <a href="./?type=<?php echo $type ?>" class="bttn-unite bttn-sm bttn-danger" >ยกเลิก</a>
                            </div>
                        </form>
                	</div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="../plugins/alertifyjs/alertify.js"></script>
    <script src="../plugins/tinymce/tinymce.min.js?v=<?php echo $v ?>"></script>
    <script src="../assets/js/script.js"></script>
    <script>textEditor()</script>
    <iframe src="" name="ifr" style="display:none;" frameborder="0"></iframe>
</body>

</html>
