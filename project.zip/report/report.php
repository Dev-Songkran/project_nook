<?php 
include '../inc/config.inc.php';
include '../inc/function.php';
$id = intval($_GET[id]);
$sel = select("$tb_report","where id='$id'");
$news = select("$news_type","where id='$sel[news_type]'");
 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ระบบบริหารจัดการเอกสารงานธุรการออนไลน์</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <div style="width: 1000px;padding: 50px 20px;">
        <h3 class="text-center"><?php echo $sel[topic] ?></h3>
        <p style="    text-align: right;    font-size: 13px;    color: #333;">เมื่อวันที่ <?php echo datathai($sel[postdate]) ?></p>
        <?php 
            if($sel[news_type]!=0){
         ?>
        <div style="margin:10px 0">ประเภทข่าว : <?php echo $news[topic] ?></div>
        <?php } ?>
        <div style="margin:10px 0">ไฟล์แนบ : <a href="../filesAttach/report/<?php echo $sel[filename] ?>"><?php echo $backend ?>filesAttach/report/<?php echo $sel[filename] ?></a></div>
        รายละเอียด
        <div style="background:#fff;padding: 10px; min-height: 450px;">
             <?php echo $sel[detail] ?>
        </div>
    </div>
    <script>window.print()</script>
</body>

</html>
