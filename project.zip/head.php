<section>
    <nav>
        <div class="head_name">ระบบบริหารจัดการเอกสารงานธุรการออนไลน์</div>
        <ul class="tool">
            <li>
                <a href="javascript:void(0)">
                    <i class="material-icons">person</i>
                    <span> Login as : Administartor</span>
                </a>
                <ul>
                    <li>
                        <a href="">
                            <i class="material-icons">power_settings_new</i>
                            <span>ออกจากระบบ</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>
</section>
